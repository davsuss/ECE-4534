/* 
 * File:   sensors.h
 * Author: Alex
 *
 * Created on April 3, 2014, 1:30 PM
 */

#ifndef SENSORS_H
#define	SENSORS_H

/////////////////////////////////////////
// Distance measuring stuff
///////////////////////////////////////////

// Variables to hold raw data values for the 3 main sensors
//extern unsigned int IR1Raw;
//extern unsigned int IR2Raw;
//extern unsigned int SonarRaw;

// Array of the final message format to send over I2C
// Ultrasonic Data (2 bytes) | IR1 (2 bytes) | IR2 (2 bytes)
extern unsigned char sendSensor[6];

extern int readyFlag;
//////////////////////////////////////////
// Start/Stop line stuff
/////////////////////////////////////////

// These LineSensor variables will hold the ADC values for each line sensor in the array
extern int LineDetected;

// To hold which state the rover should be in: set flag to 1 when stop line detected
// (When the majority of line sensors detect the line then declare that its time to stop)
// Moving = 0;
// Stop line detected = 1;
unsigned int StopFlag = 0;

#endif	/* SENSORS_H */

