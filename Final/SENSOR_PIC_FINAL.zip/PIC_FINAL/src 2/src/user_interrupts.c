// This is where the "user" interrupts handlers should go
// The *must* be declared in "user_interrupts.h"

#include "maindefs.h"
#ifndef __XC8
#include <timers.h>
#else
#include <plib/timers.h>
#endif
#include "user_interrupts.h"
#include "messages.h"
#include "plib/adc.h"
#include "sensors.h"
#include "debug.h"
//#include "my_i2c.h"

// A function called by the interrupt handler
// This one does the action I wanted for this program on a timer0 interrupt
int x = 0;
int i = 0;
int length = 0;

int sensorNumber = 0;
unsigned int IR1Raw = 0;
unsigned int IR2Raw = 0;
unsigned int SonarRaw = 0;

int LineSensorNumber = 0;
unsigned int Line1Raw = 0;
unsigned int Line2Raw = 0;
int Line1Detected = 0;
int Line2Detected = 0;
int totalLines = 0;
int LineDetected = 0;

unsigned char sendSensor[6];
int readyFlag = 0;

void timer0_int_handler() {
    unsigned int val;
    int length, msgtype;

    // toggle an LED
#ifdef __USE18F2680
    LATBbits.LATB0 = !LATBbits.LATB0;
#endif
    // reset the timer
    WriteTimer0(0);

        //LATBbits.LATB7 = Line1Detected;

    // Initialize the send msg
    //MsgToSend = 0;
    
    // try to receive a message and, if we get one, echo it back
   // length = FromMainHigh_recvmsg(sizeof(val), (unsigned char *)&msgtype, (void *) &val);
   // if (length == sizeof (val)) {
    if (sensorNumber == 0){
    // Front Sensor
    OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH2 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_2ANA);
    //sensorNumber = 0;
    //IR1Raw = 0;
    ConvertADC();
    }

    else if (sensorNumber == 1){
    // Configure for first IR sensor
    OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH0 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_0ANA);
    //sensorNumber = 1;
    //IR2Raw = 0;
    ConvertADC();
    }

    else if (sensorNumber == 2){
    // Reconfigure for second IR sensor
    OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH1 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_1ANA);
    //sensorNumber = 2;
    //SonarRaw = 0;
    ConvertADC();
    }

    else {
    // Line Sensor
    OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH11 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_11ANA);
    ConvertADC();
    }
}

// A function called by the interrupt handler
// This one does the action I wanted for this program on a timer1 interrupt

void timer1_int_handler() {
    unsigned int result;

    // read the timer and then send an empty message to main()
#ifdef __USE18F2680
    LATBbits.LATB1 = !LATBbits.LATB1;
#endif

    //result = ReadTimer1();
    //ToMainLow_sendmsg(0, MSGT_TIMER1, (void *) 0);

    // reset the timer
    WriteTimer1(0);
/*
    if (LineSensorNumber == 0) {
        OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH8 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_8ANA);
        ConvertADC();
    }
    else if (LineSensorNumber == 1) {
        OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH9 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_9ANA);
        ConvertADC();
    }
    else if (LineSensorNumber == 2) {
        OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH10 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_10ANA);
        ConvertADC();
    }
    else if (LineSensorNumber == 3) {
        OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH11 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_11ANA);
        ConvertADC();
    }
    else {
        OpenADC(ADC_FOSC_16  & ADC_RIGHT_JUST & ADC_20_TAD, ADC_CH12 & ADC_INT_ON & ADC_REF_VDD_VSS, ADC_12ANA);
        ConvertADC();
    }*/
}
void adc_int_handler()
{
    unsigned int result;
    result = ReadADC();

    // IR Sensor #1
    if (sensorNumber == 0){
       // SonarRaw = 257;
       SonarRaw = result;
          sendSensor[0] = (SonarRaw >> 8) & 0xFF;
           sendSensor[1] = (SonarRaw & 0xFF);
        sensorNumber++;
    }
    // IR Sensor #2
    else if (sensorNumber == 1){
        // IR1Raw = 514;
        IR1Raw = result;
        sendSensor[2] = (IR1Raw >> 8) & 0xFF;
        sendSensor[3] = (IR1Raw & 0xFF);
        sensorNumber++;
    }
    // Sonar Sensor
    else if (sensorNumber == 2){
        //  IR2Raw = 771;
        IR2Raw = result;
        sendSensor[4] = (IR2Raw >> 8) & 0xFF;
        sendSensor[5] = (IR2Raw & 0xFF);
/*
        sendSensor[8] = 8;
        sendSensor[7] = 7;
        sendSensor[6] = 6;
        sendSensor[5] = 5;
        sendSensor[4] = 4;
        sendSensor[3] = 3;
        sendSensor[2] = 2;
        sendSensor[1] = 1;
        sendSensor[0] = 0;

        sendSensor[0] = (SonarRaw >> 8) & 0xFF;
        sendSensor[1] = (SonarRaw & 0xFF);
        sendSensor[2] = (IR1Raw >> 8) & 0xFF;
        sendSensor[3] = (IR1Raw & 0xFF);
        sendSensor[4] = (IR2Raw >> 8) & 0xFF;
        sendSensor[5] = (IR2Raw & 0xFF);
*/
    //    sendSensor[0] = (1) & 0xFF;
    //    sendSensor[1] = (2 & 0xFF);
    //    sendSensor[2] = (3) & 0xFF;
    //    sendSensor[3] = (4 & 0xFF);
    //    sendSensor[4] = (5) & 0xFF;
    //    sendSensor[5] = (6 & 0xFF);
        sensorNumber++;
        //sensorNumber = 0;
        //flipDBG(1);
        //ToMainHigh_sendmsg(6, MSGT_I2C_DATA, (void *) sendSensor);
    }
    
    else {
        Line1Raw = result;
        sensorNumber = 0;
        //flipDBG(1);
        if (Line1Raw > 0x1D1) {
            //LATBbits.LATB7 = 1;
            Line1Detected = 1;
            LineDetected = 1;
        }
        else {
            //LATBbits.LATB7 = 0;
            Line1Detected = 0;
            LineDetected = 0;
        }
        ToMainHigh_sendmsg(6, MSGT_I2C_DATA, (void *) sendSensor);
    }
    // Line Sensors
    /*
    if (LineSensorNumber == 0){
        Line1Raw = result;
        if (Line1Raw >= 310){
            Line1Detected = 1;
        }
        else {
            Line1Detected = 0;
        }
        LineSensorNumber++;
    }
    else if (LineSensorNumber == 1){
        Line2Raw = result;
        if (Line2Raw >= 310){
            Line2Detected = 1;
        }
        else {
            Line2Detected = 0;
        }
        LineSensorNumber++;
    }
    else if (LineSensorNumber == 2){
        Line3Raw = result;
        if (Line3Raw >= 310){
            Line3Detected = 1;
        }
        else {
            Line3Detected = 0;
        }
        LineSensorNumber++;
    }
    else if (LineSensorNumber == 3){
        Line4Raw = result;
        if (Line4Raw >= 310){
            Line4Detected = 1;
        }
        else {
            Line4Detected = 0;
        }
        LineSensorNumber++;
    }
    else {
        Line5Raw = result;
        if (Line5Raw >= 310){
            Line5Detected = 1;
        }
        else {
            Line5Detected = 0;
        }

        totalLines = Line1Detected + Line2Detected + Line3Detected + Line4Detected + Line5Detected;
        if (totalLines >= 3){
            // Line detected
            LATBbits.LATB7 = 1;
        }
        else {
            // Line not detected
            LATBbits.LATB7 = 0;
        }

        LineSensorNumber = 0;
    }*/
}